package safeparrots;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.animal.parrot.Parrot;
import net.minecraft.world.item.Items;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SafeParrotsMod implements ModInitializer {
	public static final String MOD_ID = "safeparrots";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		UseEntityCallback.EVENT.register((player, level, hand, entity, hitResult) -> {
			if (entity instanceof Parrot && player.getItemInHand(hand).is(Items.COOKIE)) {
				return InteractionResult.FAIL;
			}

			return InteractionResult.PASS;
		});

		LOGGER.info("Safe Parrots loaded — cookie feeding to parrots is blocked on the server.");
	}
}
